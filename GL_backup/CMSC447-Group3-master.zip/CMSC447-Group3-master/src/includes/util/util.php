<!-- Makes sure <DOCTYPE> is first -->

<?php
echo "<!DOCTYPE html>";
/*****************************************************************************
 * File:    util.php
 * Created: 1 Dec 2016
 * Authors: Christian Badolato
 * Project: Retriever Marketplace
 * Description: php file with methods to increase functionality of interface
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

require_once("includes/util/googleLogin.php");

// Setting the database and getting the connection
global $database;
if(!isset($database))
{
	$database = new Database();
}
if($database->isConnected())
{
	$conn = $database->getConnection();
}
	/*********************************************************************
	* displayWelcome()
	*	no input or output. 
	* 	Description: Displays welcome message on left side of the navbar
	*********************************************************************/
	function displayWelcome()
	{
		if(isset($_SESSION['UID']) && $_SESSION['UID'] != 'temp')
		{
			
			//var_dump($_SESSION);
			global $database;
			$userData = $database->getUserData($_SESSION['UID']);
			
			if(!$userData)
			{
				revokeLogin();
			}
			else
			{
				$fname = $userData['fname'];
				echo "Welcome $fname!";
				return;
			}
		}
		revokeLogin();
		echo "Welcome! Please Log In";
	}
	
	/*********************************************************************
	* displayMessageButton()
	*	no input or output
	* 	Description: Displays messaging button if user is logged in
	*********************************************************************/
	function displayMessageButton()
	{
		if(isset($_SESSION['UID']) && $_SESSION['UID'] != 'temp')
		{
			echo "<div class='messages'>";
				echo "<a href=\"conversations.php\"><img src=\"img/convo_read.png\"
					alt=\"Messages\" class=\"messages\"></a>";
			echo "</div>";
		}
	}
	
	/*********************************************************************
	* errorRedirect()
	* 	$error - The error message as a string
	*	
	* 	Description: Redirects to the error page with proper error text
	*********************************************************************/
	function errorRedirect($error)
	{
		$_SESSION['error'] = true;
		$_SESSION['error_message'] = $error;
		header('Location: error.php');
		exit;
	}
	
	/*********************************************************************
	* isLoggedIn()
	* 	no input
	*	output: boolean 
	* 	Description: checks if the user is currently logged in or not	********************************************************************/
	function isLoggedIn()
	{
		return (isset($_SESSION['UID']) && $_SESSION['UID'] != 'temp');
	}
	
	/*********************************************************************
	* clean_input()
	* 	input: string as $data
	*	output: returns a formatted string back
	* 	Description: Sanitizes string inputs for potential code injection	********************************************************************/ 
	function cleanInput($data) {
		$data = strip_tags($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	/*********************************************************************
	* displayDir()
	* 	input: string as $dir
	*	output: none
	* 	Description: Active Directory Page Display	********************************************************************/ 
	function displayDir($dir)
	{

	  echo "<li";
	  if($dir=="home") {
		echo " class=\"current\"";
	  }
	  echo "><a href=\"welcome.php\">Home</a></li>";

	  echo "<li";
	  if($dir=="market") {
		echo " class=\"current\"";
	  }
	  echo "><a href=\"market.php\">Market</a></li>";

	  echo "<li";
	  if($dir=="profile") {
		echo " class=\"current\"";
	  }
	  echo "><a href=\"profile.php\">Profile</a></li>";
	}

	/*********************************************************************
	* displayDir()
	* 	input: 2 strings as $dir and $sub
	*	output: none
	* 	Description: Active Subdirectory Page
					depending on the page selection, the correct
					interface will be displayed
	********************************************************************/ 
	function displaySub($dir, $sub)
	{

	  if($dir=="home" || $dir=="legal")
		{

			echo "<li";
			if($sub=="welcome") {
				echo " class=\"current\"";
			}
			echo "><a href=\"welcome.php\">Welcome</a></li>";

			echo "<li";
			if($sub=="tutorial") {
				echo " class=\"current\"";
			}
			echo "><a href=\"tutorial.php\">Tutorial</a></li>";

			echo "<li";
			if($sub=="about") {
				echo " class=\"current\"";
			}
			echo "><a href=\"about.php\">About</a></li>";
		}
	  else if($dir=="market")
		{

			echo "<li";
			if($sub=="browse") {
				echo " class=\"current\"";
			}
			echo "><a href=\"market.php\">Browse</a></li>";

			echo "<li";
			if($sub=="post") {
				echo " class=\"current\"";
			}
			echo "><a href=\"post.php\">Post Listing</a></li>";

			echo "<li";
			if($sub=="exchange") {
				echo " class=\"current\"";
			}
			echo "><a href=\"exchange.php\">Exchange</a></li>";
	  }
	  else if($dir=="profile")
		{

			echo "<li";  
			if($sub=="account") {
				echo " class=\"current\"";
			}
			echo "><a href=\"profile.php\">Account</a></li>";

			echo "<li";
			if($sub=="listings") {
				echo " class=\"current\"";
			}
			echo "><a href=\"listings.php\">Listings</a></li>";

			echo "<li";
			if($sub=="conversations") {
				echo " class=\"current\"";
			}
			echo "><a href=\"conversations.php\">Conversations</a></li>";

			echo "<li";
			if($sub=="contracts") {
				echo " class=\"current\"";
			}
			echo "><a href=\"contracts.php\">Contracts</a></li>";
	  }
	  else
		{
			echo "<li><a href=\"\">Unknown Page Var</a></li>";
	  }
	}

	/*********************************************************************
	* displayLegal()
	* 	input: 2 strings as $dir and $sub
	*	output: none
	* 	Description: Active Legal Page Display
					depending on the page selection, the correct
					interface will be displayed. Though here it will
					only vary between displaying pages that are related to 
					terms of service and other legal docs. 
	********************************************************************/ 

	function displayLegal($dir, $sub)
	{

	  if($dir=="legal")
		{

			echo "<li";
			if($sub=="privacy") {
				echo " class=\"current\"";
			}
			echo "><a href=\"privacy.php\">Privacy Policy</a></li>";

			echo "<li";
			if($sub=="terms") {
				echo " class=\"current\"";
			}
			echo "><a href=\"terms.php\">Terms of Use</a></li>";
		}
	  else
		{
			echo "<li><a href=\"privacy.php\">Privacy Policy</a></li>";
			echo "<li><a href=\"terms.php\">Terms of Use</a></li>";
	  }
	}
?>
