<?php
/*****************************************************************************
 * File: details.php
 * Created: 2 Dec 2016
 * Authors: Kush Patel
 * Project: Retriever Marketplace
 * Description: Retrieves and displays details of listings.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "market";
$thisSub = "listings";

//Verify User Login
if(!isLoggedIn())
{
	$error = "Registered Users Only. Please \"Sign-In\" to view this page.";
	errorRedirect($error);
}
else
{
	//Retrieve User Information
	$user = $database->getUserData($_SESSION['UID']);
}

//Verify User Connection
if($user == FALSE)
{
	$error = "Connection to database lost.";
	errorRedirect($error);
}

//Verify lid Variable was Posted
if(isset($_GET['lid'])){
	
	//Retrieve Market Data
	if($database->isConnected()) {
		
		$lid = $_GET['lid'];
		$stmt = $conn->prepare("SELECT * FROM `listings` WHERE `LID` = $lid");
		$stmt->execute();
		$list = $stmt->fetch(PDO::FETCH_ASSOC);		
		
		$sellerID = $list['sellerID'];
		$stmt = $conn->prepare("SELECT * FROM `users` WHERE `UID` = $sellerID");
		$stmt->execute();
		$user = $stmt->fetch(PDO::FETCH_ASSOC);	
	}
	else {
		$error = "Connection to database lost.";
		errorRedirect($error);
		return;
	}
}
/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
?>

<div class="page">
	<h2><?php echo $list['title'];?></h2>
	<hr>
	<?php
		$image = $list['image'];
		echo '<div class="detailpic">';
		echo '<img class="marketpic" src="data:image;base64,'.$image.' ">';
		echo '</div>';
	?>	
	<div class="form">
	<fieldset>
		<legend><strong>Listing Info</strong></legend>
		<span>
			<p><strong>Description</strong></p>
			<p><?php echo $list['description'];?></p>
		</span>
		<span>
			<p><strong>Meeting Location</strong></p>
			<p><?php echo $list['location'];?></p>
		</span>
		<span>
			<p><strong>Price</strong></p>
			<p>$<?php echo $list['price'];?></p>
		</span>
	</fieldset><br/>
	</div>

	<div class="form">
	<fieldset>
		<legend><strong>Seller Info</strong></legend>
		<span>
			<p><strong>Name</strong></p>
			<p><?php echo $user['displayName'];?></p>
		</span>
		<span>
			<p><strong>Email</strong></p>
			<p><?php echo $user['email'];?></p>
		</span>	
		<span>
			<p><strong>Phone Number</strong></p>
			<p><?php echo $user['phoneNumber'];?></p>
		</span>
	</fieldset><br/>

	</div>
</div>

<?php
//Output Footer
require_once("includes/footer.php");
?>
