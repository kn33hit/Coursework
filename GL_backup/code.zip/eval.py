import sys

inputFile = open(sys.argv[1], "r")
outputFile = open(sys.argv[2], "r")
correct = 0
totalAccuracy = 0
lineCount = 0

for line in inputFile:
    print "\nInput: ", line
    totalSlangTerms = input("Number of slang terms to be translated: ")
    print "Output: ", outputFile.readline()
    if(totalSlangTerms != 0):
        numCorrectTranslations = input("Number of slang terms translated correctly: ")
        print "Translation Accuracy: ", 100*numCorrectTranslations/float(totalSlangTerms), "%"
        totalAccuracy += 100*numCorrectTranslations/float(totalSlangTerms)
    else:
        correct += 1
       
    lineCount += 1
    print "\n============================================"

print "\n============ Evaluation Summary ============"
print "Average Accuracy for all sentences: ", totalAccuracy/float(lineCount), "%"


inputFile.close()
outputFile.close()
