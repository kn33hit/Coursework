<?php
/*****************************************************************************
 * File: 	index.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Default server directory. Redirects user to homepage.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

header("Location: welcome.php");

exit();

?>
