<?php
/*****************************************************************************
 * File:    contracts.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Retrieves and displays list of user contracts and their status
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "profile";
$thisSub = "contracts";

//Verify User Login
if(!isLoggedIn())
{
	$error = "Registered Users Only. Please \"Sign-In\" to view this page.";
	errorRedirect($error);
}

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
?>
<div class="page">
	<h2>Contracts</h2>
	<hr>
	<p>
		Work in Progress
	</p>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>
