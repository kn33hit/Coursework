<?php
/*****************************************************************************
 * File: 	error.php
 * Created: 1 Dec 2016
 * Authors: Christian Badolato
 * Project: Retriever Marketplace
 * Description: Displays given error message string. Website error reporting.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "home";
$thisSub = "";

//Checking for error, if none exists, set direct access error
if($_SESSION['error'])
{
	$error = $_SESSION['error_message'];
}
else
{
	$error = "No error detected. Did you mean to visit this page?";
}

//Reset error status
$_SESSION['error'] = false;
unset($_SESSION['error_message']);

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

?>
<div class='page'>
	<h1>Oops, something went wrong!</h1>
	<h2><?php echo $error;?></h2>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>

