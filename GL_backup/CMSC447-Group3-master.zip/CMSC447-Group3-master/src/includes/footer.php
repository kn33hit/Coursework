<?php
/*****************************************************************************
 * File: 	footer.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Closing HTML tags. Clear class handles float div issues.
 * 
 * Known Issues:
 * **************************************************************************/

?>
			</div>
			<div class="clear"></div>
		</div>
	</body>
</html>