<?php
/*****************************************************************************
 * File:    conversations.php
 * Created: 1 Dec 2016
 * Authors: Neh Patel, Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Displays list of all user conversation threads.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "profile";
$thisSub = "conversations";

//Verify User Login
if(!isLoggedIn())
{
	$error = "Registered Users Only. Please \"Sign-In\" to view this page.";
	errorRedirect($error);
}

function displayMessages()
{
	//External Globals Resolution
	global $database;
	global $conn;

	//Local Variable Definition
	$sql = "";
	
	//Retrieve Market Data
	if($database->isConnected())
	{
		$stmt = $conn->prepare($sql);
		$stmt->execute();
		$mess = $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	else
	{
		$error = "Connection to database lost.";
		errorRedirect($error);
		return;
	}
}

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content

?>
<div class="page">
	<h2>Conversations</h2>
	<hr>
	<p>
		Work in Progress
	</p>	
</div>
<?php

require_once("includes/footer.php");

?>



