<?php
/*****************************************************************************
 * File: 	terms.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Loads TOS HTML page
 * 
 * Known Issues:
 * **************************************************************************/
session_start();
 
/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "legal";
$thisSub = "terms";

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
require_once("includes/html/tos.html");

//Output Footer
require_once("includes/footer.php");

?>