<?php
/*****************************************************************************
 * File:    market.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Retrieves and displays market category information.
 * 				Retrieves and displays listings for selected category.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "market";
$thisSub = "browse";

//Verify User Login
if(!isLoggedIn())
{
	$error = "Registered Users Only. Please \"Sign-In\" to view this page.";
	errorRedirect($error);
}

//Market Variable Declaration
$maxItems = 50;

//retrieveCategories
function retrieveCategories()
{
	//External Globals Resolution
	global $database;
	global $conn;
	
	//Local Variable Declaration
	$sql = "SELECT * FROM `categories`";
	
	if($database->isConnected())
	{
		$stmt = $conn->prepare($sql);
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	else
	{
		$error = "Connection to database lost.";
		errorRedirect($error);
		return;
	}
}

//retrieveListings
function retrieveListings($category,$title)
{
	//External Globals Resolution
	global $database;
	global $conn;

	//Local Variable Declaration
	$sql = "SELECT * FROM `listings`";

	//Check Query Criteria
	if(($category != "") && ($title != ""))
	{
		$sql = "SELECT * FROM `listings` WHERE `categoryID`=$category AND `title` LIKE %$title%";
	}
	if(($category != "") && ($title == ""))
	{
		$category = intval($category);
		$sql = "SELECT * FROM `listings` WHERE `categoryID`=$category";
	}
	if(($category == "") && ($title != ""))
	{
		$sql = "SELECT * FROM `listings` WHERE `title` LIKE %$title%";
	}
	
	//Query Database
	if($database->isConnected())
	{		
		$stmt = $conn->prepare($sql);
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	else
	{
		$error = "Connection to database lost.";
		errorRedirect($error);
		return;
	}
}

//displaySearch 
function displaySearch()
{	
	//Retrieve Category Data
	if(!isset($_SESSION['category']))
	{
		$_SESSION['category'] = retrieveCategories();
	}
		
	//Output Form Head
	echo "<div class=\"form\">";
	echo "<form action=\"market.php\" method=\"post\"><fieldset>";
	echo "<legend><strong>Search Market</strong></legend>";
	echo "<span><p><strong>Select Category</strong></p>";
	echo "<p><strong>Search by Name</strong></p></span>";

	//Output Category Dropdown
	echo "<span><p><select name=\"category\">";
	echo "<option value=\"\">All</option>";
	for($i = 0; $i < count($_SESSION['category']); $i++)
	{
		echo "<option value=".$_SESSION['category'][$i]['categoryID'].">";
		echo $_SESSION['category'][$i]['categoryName']."</option>";
	}
	echo "</select></p>";

	//Output Text Input
	echo "<p><input type=\"text\" name=\"title\" maxlength=\"40\"></p>";

	//Output Submit
	echo "<p><input type=\"submit\" name=\"search\"
			value=\"Search\"></p></span>";
	
	//Output Form Close
	echo "</fieldset></form></div>";
}

//displayListings
function displayListings()
{
	//Local Variable Declaration
	$listingData;
	$category = "";
	$title = "";
	$header = "All Marketplace Listings";
	
	//Check for Posted Search Criteria
	if(isset($_POST['category']))
	{
		$category = $_POST['category'];
		$header = "Search Result Listings";
	}
	if(isset($_POST['title']))
	{
		$title = cleanInput($_POST['title']);
		$header = "Search Result Listings";
	}
	
	//Retrieve Listing Data
	$listingData = retrieveListings($category,$title);

	//Output Header
	echo "<h2>".$header."</h2>";
	
	//Output Listings
	if(count($listingData) == 0)
	{
		echo "<p><strong>No Listings Found</strong></p>";
	}
	else
	{
		echo "<div class=\"market-flex\">";
		for($i = 0; $i < count($listingData); $i++)
		{
			$photo = $listingData[$i]['image'];
			$price = $listingData[$i]['price'];
			
			echo "<a href=\"details.php?lid='"
					.$listingData[$i]['LID']."'\" onclick=\"post\">";
			echo "<div class=\"listing\">";
			echo "<div class=\"marketpic\"><img class=\"marketpic\"
					src=\"data:image;base64,".$photo."\"></div>";
			echo "<h3>".$listingData[$i]['title']."</h3>";
			echo "<p>".$listingData[$i]['description']."</p>";
			echo "<p><strong>Price:</strong> $".$price."</p>";
			echo "</div></a>";
		}
		echo "</div>";
	}
}

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
?>
<div class="page">
	<h2>Browse Marketplace</h2>
	<hr>
	<p>Select a listing Category or Search for a specific listing name.</p>

	<?php displaySearch();?>

	<?php displayListings();?>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>
