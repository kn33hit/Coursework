import nltk 
import enchant 

def checkSymbol(word):
    file = open("symbols.txt", 'r')
    for line in file:
        line = line[:-1]
        if(line == word):
            return True 
    file.close()
    return False


def checkAbbrev(word):
    word = word + "\n"
    with open("abbrevWord.txt",'r') as f:
        for line in f:
            if word.lower() == line.lower():
                return True
    return False

def replaceNumbers(s):

    for i in range(int(len(s))):
        if(s[i] == "1"):
            s = s[0:i] + "i" + s[i+1:]
        elif(s[i] == "2"):
            s = s[0:i] + "r" + s[i+1:]
        elif(s[i] == "3"):
            s = s[0:i] + "e" + s[i+1:]
        elif(s[i] == "4"):
            s = s[0:i] + "a" + s[i+1:]
        elif(s[i] == "5"):
            s = s[0:i] + "s" + s[i+1:]
        elif(s[i] == "0"):
            s = s[0:i] + "o" + s[i+1:]
        elif(s[i] == "@"):
            s = s[0:i] + "a" + s[i+1:]
        elif(s[i] == "$"):
            s = s[0:i] + "s" + s[i+1:]

    return s


def main():
    d = enchant.Dict("en_US")
    file = open("input.txt",'r')
    out = open("OUT.txt", 'w')
    for line in file:
        line = line[:-1].lower()
        tokens = nltk.word_tokenize(line)
        for n in tokens:
            n = replaceNumbers(n)
            if((d.check(n) == False) and (checkSymbol(n) == False) and (checkAbbrev(n) == False)):
                out.write(n + "\n")


    file.close()


main()
