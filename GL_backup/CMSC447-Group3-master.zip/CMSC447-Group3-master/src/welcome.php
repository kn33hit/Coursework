<?php
/*****************************************************************************
 * File:    welcome.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Loads welcome HTML page. Homepage of Retriever Marketplace.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();
 
/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "home";
$thisSub = "welcome";

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
include("includes/html/welcome.html");

//Output Footer
require_once("includes/footer.php");

?>