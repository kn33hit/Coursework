<?php
/*****************************************************************************
 * File: 	tutorial.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Loads Tutorial HTML page.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();
 
/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "home";
$thisSub = "tutorial";

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
?>
<div class="page">
	<h2>Guide to Retriever Marketplace</h2>
	<hr>
	<p>
		Work in Progress
	</p>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>