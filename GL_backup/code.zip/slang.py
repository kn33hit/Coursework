import nltk
import enchant
from difflib import SequenceMatcher

RATE = 0.55
#===================================================================================================


def code(tokens):
    final = ""
    d = enchant.Dict("en_US")
    # word lookup in the freaking abbreviation and slang dictionary
    # code to strip that dictionary into proper readable file for LM Tool
    # word recommendation from pyenchant
    # then use word2vec to replace

    for word in tokens:
        word = numToChar(word)
        slang = checkSlang(word)
        abbrev = checkAbbrev(word)
        if(d.check(word) == True):
            final = final + word + " "
        if(slang == True):
            file1 = "slangs.txt"
            file2 = "words.txt"
            isPronoun = 1
            word = switchWord(word,file1,file2,isPronoun)
            final = final + word + " "
        if(abbrev == True):
            file1 = "abbrevWord.txt"
            file2 = "abbreviation.txt"
            isPronoun = 0
            word = switchWord(word,file1,file2,isPronoun)
            final = final + word.upper() + " "
        if(slang == False and abbrev == False and d.check(word) == False):
            # AND IS CAUSING RANDOM THINGS FOR BTW
            final = final + word + " "
            print "\"" + word + "\" is not in corpus"

    return final


def switchWord(word,file1,file2,isPronoun):
    # file 1 is being switch to file 2 word
    final = ""
    count = 0
    slangP = open("slangsPronun.txt",'r')
    slang = open("slangs.txt",'r')
    inFile1 = open(file1,'r')
    inFile2 = open(file2,'r')

    # check the pronun files to match pronuns and keeps track of count
    # best match is replaces using gin's function
    if(isPronoun == 1):
        # do slang pronoun part
        count3 = 1

        for line in slang:
            line = line[:-1]
            if(line.lower() == word.lower()):
                break
            else:
                count3 = count3 + 1

        count4 = 1
        for line in slangP:
            if(count4 == count3):
                wordPronun = line[:-1]
                final = similar(wordPronun,word)
                break
            else:
                count4 = count4 + 1

    else:
        # do abbreviation

        count1 = 1

        for line in inFile1:
            if(line.lower() == (word.lower() + "\n")):
                break
            else:
                count1 = count1 + 1

        count2 = 1
        for line in inFile2:
            if(count2 == count1):
                final = line[1:-1]
                break
            else:
                count2 = count2 + 1

    slangP.close()
    slang.close()
    inFile1.close()
    inFile2.close()
    return final

def checkAbbrev(word):
    word = word + "\n"
    with open("abbrevWord.txt",'r') as f:
        for line in f:
            if word.lower() == line.lower():
                return True
    return False

def checkSlang(word):
    word = word + "\n"
    with open("slangs.txt",'r') as f:
        for line in f:
            if word.lower() == line.lower():
                return True
    return False


def numToChar(s):
    for i in range(int(len(s))):
        if(s[i] == "1"):
            s = s[0:i] + "i" + s[i+1:]
        elif(s[i] == "2"):
            s = s[0:i] + "r" + s[i+1:]
        elif(s[i] == "3"):
            s = s[0:i] + "e" + s[i+1:]
        elif(s[i] == "4"):
            s = s[0:i] + "a" + s[i+1:]
        elif(s[i] == "5"):
            s = s[0:i] + "s" + s[i+1:]
        elif(s[i] == "0"):
            s = s[0:i] + "o" + s[i+1:]
        elif(s[i] == "@"):
            s = s[0:i] + "a" + s[i+1:]
        elif(s[i] == "$"):
            s = s[0:i] + "s" + s[i+1:]
    return s

# takes the already found pronunciation of slang word
# takes the pronun of regular words and changes it around
def similar(wordPronun,term):


    similarity = 0
    accept_rate = RATE
    similar_word = ""
    dic = open("wordsPronun.txt", 'r')
    inFile2 = open("words.txt",'r')
    wordPronun = "\t" + wordPronun

    for word in dic:
        word = word[:-1]
        similarity = SequenceMatcher(None, wordPronun, word).ratio()
        if similarity > accept_rate:
            similar_word = word
            accept_rate = similarity
    if accept_rate > 0.8:
        word = similar_word
    else:
        word = wordPronun

    final = term
    dic.close()
    dic = open("wordsPronun.txt", 'r')
    count1 = 1
    for line in dic:
        line = line[:-1]
        if(line.lower() == word.lower()):
            break
        else:
            count1 = count1 + 1

    count2 = 1
    for line in inFile2:
        if(count2 == count1):
            final = line[:-1]
            break
        else:
            count2 = count2 + 1


    return final


#===================================================================================================
#===================================================================================================
#===================================================================================================

def main():
    input = open("input.txt",'r')
    output = open("output.txt",'w')
    d = enchant.Dict("en_US")
    for line in input:
        final = ""
        line = line[:-1]
        tokens = nltk.word_tokenize(line)
        final = code(tokens)
        output.write(final+"\n")

    input.close()
    output.close()








#===================================================================================================
main()
