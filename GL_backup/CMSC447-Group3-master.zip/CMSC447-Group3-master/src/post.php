<?php
/*****************************************************************************
 * File:    post.php
 * Created: 1 Dec 2016
 * Authors: Kush Patel, Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Enables user to post a listing to the market database.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "market";
$thisSub = "post";

//Verify User Login
if(!isLoggedIn())
{
	$error = "Registered Users Only. Please \"Sign-In\" to view this page.";
	errorRedirect($error);
}

//Post User Listing to Database
if(isset($_POST['postOffer']))
{
	$title = rtrim(cleanInput($_POST['title']));
	$description = rtrim(cleanInput($_POST['description']));
	$categoryID = rtrim(cleanInput($_POST['categoryID']));
	$location = rtrim(cleanInput($_POST['location']));
	$price = rtrim(cleanInput($_POST['price']));

	$isActive = TRUE;	
	$sellerID = intval($_SESSION['UID']);
	$image = base64_encode(file_get_contents(addslashes($_FILES['image']['tmp_name'])));

	// Add listing
	$query = $conn->prepare("INSERT INTO `listings`(`title`, `description`, `image`, `categoryID`, `sellerID`, `isActive`, `location`, `price`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
	$query->bindParam(1, $title);
	$query->bindParam(2, $description);
	$query->bindParam(3, $image);
	$query->bindParam(4, $categoryID);
	$query->bindParam(5, $sellerID);
	$query->bindParam(6, $isActive);
	$query->bindParam(7, $location);
	$query->bindParam(8, $price);
	$query->execute();

	//Redirect to User Listings to Verify Post Successful
	header('Location: listings.php');
	exit;

}

/*Output Section - HTML Output OK*********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
?>
<div class="page">
<h2>Post a New Listing</h2>
<hr>
<p>Complete the form below to post a new Listing to the Marketplace.</p> 

<div class="form">
	<form method='post' action='post.php' enctype='multipart/form-data'>
		<fieldset>
			<legend><strong>Post Your Listing</strong></legend>
			<span>
				<label for="title">Title:</label>
				<input type='text' name='title' maxlength='60'
					value='<?php echo $title;?>' required='required'></input>
			</span>
			<br/>Add Photo:
			<input type='file' name='image'
				accept='image/jpeg, image/png' onchange='upload(event);'>
				<br/><img id='pic' alt='Upload an Image' width='220' height='200'/>
				<script>
					var upload = function(event) {
						var pic = document.getElementById('pic');
						pic.src = URL.createObjectURL(event.target.files[0]);
					};
				</script>
			</input>
			<br/>
			<br/>Category:
			<select name='categoryID'>
				<option value='12'>Miscellaneous</option>
				<option value='1'>Automotive/Vehicles</option>
				<option value='2'>Beauty</option>
				<option value='3'>Books</option>
				<option value='4'>Clothing/Accessories</option>
				<option value='5'>Electronics</option>
				<option value='6'>Home/Garden</option>
				<option value='8'>Services</option>
				<option value='9'>Software</option>
				<option value='10'>Sports/Outdoors</option>
				<option value='11'>Toys/Games</option>
			</select>
			<br/>
			<br/>Details:<br/>
			<textarea name='description' required='required' rows='7' cols='50'
				placeholder='Describe this listing. Specify item condition or service conditions.'></textarea>
			<br/>
			<br/>Meeting Location:<br/>
			<textarea name='location' required='required' rows='7' cols='50'
				placeholder='Specify the time and location to meet for this listing.'></textarea>
			<br/>
			<br/><span>
				<label for="price">Price:</label>
				<input type='text' pattern ='[0-9]?[0-9]\.[0-9][0-9]' name='price'
					value='<?php echo $price;?>' maxlength='5' required='required'></input>
			</span>
			<br/><input type='submit' name='postOffer' value='Complete Listing'/>
		</fieldset>
	</form>
</div>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>
