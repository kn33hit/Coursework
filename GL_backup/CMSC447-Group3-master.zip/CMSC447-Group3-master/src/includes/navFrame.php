<?php
/*****************************************************************************
 * File: 	navFrame.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: HTML with CSS navigation frame with php dynamic display
 *			features.
 * 
 * Known Issues:
 * **************************************************************************/
 ?>
 
<!DOCTYPE html>
<html lang="en-US">
	<link rel="icon" type="image/png" href="img/retriever1.gif">
	<meta charset="UTF-8">
	<head>
		<title>Retriever Marketplace</title>
		<link rel="stylesheet" type="text/css" href="includes/market.css">
	</head>
	<body>
		<div class="wrapper">
			<div class="sidebar">
				<div class="side-logo">
					<a href="welcome.php">
					<img src="img/retriever1.gif" alt="Home" class="logo">
					</a>
				</div>
				<div id="side-nav">
					<ul>
					<?php displaySub($thisDir, $thisSub); ?>
					</ul>
				</div>	
				<div class="sideFooter">
					<div class="side-links">
						<ul>
						<?php displayLegal($thisDir, $thisSub); ?>
						</ul>
					</div>
					<div class="toTop">
						<a href="#top">
						<img src="img/to_top.png" alt="Top" class="toTop">
						</a>
					</div>
				</div>
			</div>
			<div class="content">
				<div class="header">
					<div class="title">
						<p class="title">Retriever<br>Marketplace<br></p>
					</div>
					<?php displayLogin(); ?>	  
					<div class="messages">
						<a href="conversations.php">
						<img src="img/convo_read.png" alt="Messages"
						class="messages">
						</a>
					</div>
				</div>
				<div id="top-nav">
					<ul>
					<?php displayDir($thisDir); ?>
					<li><p><?php displayWelcome(); ?></p></li>
					</ul>
				</div>