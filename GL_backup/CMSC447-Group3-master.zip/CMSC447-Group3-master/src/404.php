<?php
/*****************************************************************************
 * File: 	404.php
 * Created: 1 Dec 2016
 * Authors: Christian Badolato
 * Project: Retriever Marketplace
 * Description: Standard HTTP 404 Status -Not Found- Output Page
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "home";
$thisSub = "";

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");
?>
<div class='page'>
	<h1>Not even we could retrieve this page!</h1>
	<h2>The requested page was not found or does not exist.</h2>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>