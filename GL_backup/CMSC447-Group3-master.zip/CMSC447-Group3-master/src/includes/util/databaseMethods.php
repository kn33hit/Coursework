<?php 
/*****************************************************************************
 * File: 	databaseMethods.php
 * Created: 1 Dec 2016
 * Authors: Christian Badolato
 * Project: Retriever Marketplace
 * Description: php file with methods to access the database. The methods are
 * 		created using a class called Database. The object then creates a
 *		database and the methods allow us to connect to the item retriever
 *		database, and depending on the methods allows the user to access and
 *		manipulate database values.
 *
 * Known Issues:
 * **************************************************************************/
class Database
{
	var $db;
	var $connectionActive;
		
	// Initializes database
	function Database()
	{
		$rs = $this->connect("item_retriever");
		return $rs;
	}

	/* connect
	   input: data base name.
	   description: connects to the database, if an error occurs it 
	   catches the error and echoes it
	*/
	function connect($dbName)
	{
	
		try {
			$db = new PDO("mysql:host=localhost;dbname=$dbName;port=3306;charset=utf8mb4", 'accessaccount', 'accesspass', array(PDO::ATTR_TIMEOUT => "30"));
			$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
			$db->setAttribute(PDO::ATTR_PERSISTENT, true);
		
			$this->connectionActive = true;
			$this->db = $db;
		}
		catch (Exception $e)
		{
			echo $e->getMessage();
			echo "Unable to connect to database";
			$this->connectionActive = false;
		}
	}
	
	/* tryConnect
	   input: None.
	   output: none.
	   description: Tries to initalize the connection if not connected
	*/
	function tryConnect()
	{
		if(!$this->connectionActive)
		{
			$this->connect("item_retriever");
		}
	}
	
	/*isConnected
	   input: None.
	   output: boolean
	   description: Returns true if the connection is active
	   */
	function isConnected()
	{
		return $this->connectionActive;
	}
	
	/*isConnected
	   input: None.
	   output: connection to db
	   description: Returns the connection
	   */	
	function getConnection()
	{
		if($this->isConnected())
		{
			return $this->db;
		}
		else
		{
			return null;
		}
	}
	
	/*getUserData
	   input: user id.
	   output: user information
	   description: returns user information, using the id provided to it 
	   returns false if an error occurs
	*/
	function getUserData($uid)
	{
		if($this->isConnected())
		{
			$sql = "SELECT * FROM `users` WHERE `UID`=$uid";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
			return $userInfo;
		}
		else
		{
			return false;
		}
	}

	/*getUserMessageData
	   input: user id.
	   output: user message information
	   description: returns user message information, using the id provided to it 
	   returns false if an error occurs
	*/
	function getUserMessageData($uid)
	{
		if($this->isConnected())
		{
			$sql = "SELECT * FROM `messages` WHERE `receiverID` = 7";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$userInfo = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $userInfo;
		}
		else
		{
			return false;
		}
	}
};
?>