<?php
/*****************************************************************************
 * File: 	profile.php
 * Created: 1 Dec 2016
 * Authors: Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Displays User Account information. Enables editing of account.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "profile";
$thisSub = "account";

//Verify User Login
if(!isLoggedIn())
{
	$error = "Registered Users Only. Please \"Sign-In\" to view this page.";
	errorRedirect($error);
}

//Profile Variable Declaration
$uid = intval($_SESSION['UID']);
$user = $database->getUserData($_SESSION['UID']);
$phoneErr = "";

//Update User Account
if(isset($_POST['updateAccount']))
{
	//Validate and Update Phone
	if(!empty($_POST['phone']))
	{
		$phone = rtrim(cleanInput($_POST['phone']));
    
		//Check Digits and Length of Ten or Empty Only
		if(preg_match("/(^[0-9]{10}$)|(^$)/",$phone))
		{
			if($database->isConnected())
			{
				//Update Phone Number
				$query = $conn->prepare("UPDATE `users` SET `phoneNumber`=? WHERE `UID`=$uid");
				$query->bindParam(1, $phone);
				$query->execute();
			}
			else
			{
				$error = "Connection to database lost.";
				errorRedirect($error);
				return;
			}
		}
		else
		{
			$phoneErr = "Invalid Phone Format";
		}
	}

	//Validate and Update Phone
	if(isset($_FILES['propic']['name']))
	{
		$image = base64_encode(file_get_contents(addslashes($_FILES['propic']['tmp_name'])));
		if($database->isConnected())
		{
			//Update Profile Picture
			$query = $conn->prepare("UPDATE `users` SET `picture`=? WHERE `UID`=$uid");
			$query->bindParam(1, $image);
			$query->execute();
		}
		else
		{
			$error = "Connection to database lost.";
			errorRedirect($error);
			return;
		}
	}
	
	//Update User Array
	$user = $database->getUserData($_SESSION['UID']);
}

if($user == FALSE)
{
	$error = "Connection to database lost.";
	errorRedirect($error);
}

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page HTML
?>
<div class="page">
	<h2><?php echo $user['displayName'];?>'s Profile</h2>
	<hr>
	<p>View and Edit your account information.</p>
	<?php
		$userPic = $user['picture'];
		echo '<div class="detailpic">';
		echo '<img class="marketpic" src="data:image;base64,'.$userPic.' ">';
		echo '</div>';
	?>	
	<div class="form">
	<fieldset>
		<legend><strong>Account Info</strong></legend>
		<div class="propic">
			<img src="img/retriever1.gif" alt="Profile Picture" class="propic">
		</div>
		<span>
			<p><strong>First Name</strong></p>
			<p><?php echo $user['fname'];?></p>
		</span>
		<span>
			<p><strong>Last Name</strong></p>
			<p><?php echo $user['lname'];?></p>
		</span>
		<span>
			<p><strong>Display Name</strong></p>
			<p><?php echo $user['displayName'];?></p>
		</span>
		<span>
			<p><strong>Email</strong></p>
			<p><?php echo $user['email'];?></p>
		</span>	
		<span>
			<p><strong>Phone Number</strong></p>
			<p><?php echo $user['phoneNumber'];?></p>
		</span>
		<span>
			<p><strong>Reputation</strong></p>
			<p><?php echo $user['reputation'];?></p>
		</span>
	</fieldset><br />

	<form action="profile.php" method="post" enctype="multipart/form-data">
	<fieldset>
		<legend><strong>Edit Account Info</strong></legend>
		<span>
			<label for="phone">Phone Number</label>
			<input type="text" name="phone"
			value="<?php echo $user['phoneNumber'];?>" maxlength="10">
			<?php echo $phoneErr; ?>
		</span>
		<span>
			<label for="propic">Profile Picture</label>
			<input type="file" name="propic" accept="image/*">
		</span>
		<span>
			<input type="submit" name="updateAccount" value="Update Info">
		</span>
	</fieldset>
	</form>
	</div>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>
