/*****************************************************************************
 * File:    javascript.js
 * Created: 1 Dec 2016
 * Authors: Christian Badolato
 * Project: Retriever Marketplace
 * Description: Javascript methods to increase interface capabilities.
 * 
 * Known Issues:
 * **************************************************************************/
<!-- Javascript functions -->
	<!--
	  // boxJumpForPhone()
	  // Preconditions: element is the element to jump from
	  // Postcondtions: Moves cursor to next text box when entering phone number
	  // allows box jump fucntionality when the user puts in their phone number
	-->
	function boxJumpForPhone(element) {
		if(element.value.length >= 3) {
			var i;
			var elements = element.form.elements;
			for(i = 0; i < elements.length; i++) {
				
				// Found the right element
				if(element == elements[i]) {
					elements[i+1].focus();
					elements[i+1].select();
					break;
				}
			}
		}
	}
	
	<!--
	  // validateRegistration()
	  // Preconditions: none
	  // Postcondtions: Validates information upon submitting,
	  //                since almost all validation is done through html,
	  //				this will be nearly empty.
	-->
	
	function validate() {
		
	}