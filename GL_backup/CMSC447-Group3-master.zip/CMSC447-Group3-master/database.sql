-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 06, 2016 at 06:24 AM
-- Server version: 5.5.50-0+deb8u1
-- PHP Version: 5.6.24-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `item_retriever`
--
CREATE DATABASE IF NOT EXISTS `item_retriever` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `item_retriever`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
`categoryID` int(11) NOT NULL,
  `categoryName` varchar(128) NOT NULL,
  `description` varchar(120) NOT NULL DEFAULT 'Default category description.' COMMENT 'category description text',
  `hexColor` varchar(6) NOT NULL DEFAULT 'ffffff' COMMENT 'hex color code'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
CREATE TABLE IF NOT EXISTS `contracts` (
`CID` int(10) unsigned NOT NULL COMMENT 'The ID of the contract',
  `buyerID` int(10) unsigned NOT NULL COMMENT 'The UID of the buyer',
  `sellerID` int(10) unsigned NOT NULL COMMENT 'The UID of the seller',
  `contractStatus` enum('NOT_INITIATED','PENDING','REJECTED_DECLINED','REJECTED_CANCELLED','COMPLETE') NOT NULL COMMENT 'The status of the contract',
  `meetingLocation` varchar(64) NOT NULL COMMENT 'The location the users will meet to exchange services',
  `approxDelieveryTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'The meeting time for the user services',
  `showSellerPhone` tinyint(1) NOT NULL COMMENT 'Whether or not the seller''s phone number should be displayed',
  `sellerPhone` varchar(10) DEFAULT NULL COMMENT 'The seller''s phone number',
  `showBuyerPhone` tinyint(1) NOT NULL COMMENT 'Whether or not the buyers phone number should be displayed',
  `buyerPhone` int(11) DEFAULT NULL COMMENT 'The buyer''s phone number',
  `itemDelivered` tinyint(1) NOT NULL COMMENT 'Whether or not the item has been delivered to the buyer',
  `paymentDelievered` tinyint(1) NOT NULL COMMENT 'Whether or not the payment was delivered to the seller'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `listings`
--

DROP TABLE IF EXISTS `listings`;
CREATE TABLE IF NOT EXISTS `listings` (
`LID` int(10) unsigned NOT NULL COMMENT 'The listing''s ID',
  `title` varchar(60) NOT NULL COMMENT 'The listing''s title',
  `description` text NOT NULL COMMENT 'The body of the listing',
  `image` longblob COMMENT 'The encoding of the listing''s image',
  `categoryID` int(11) NOT NULL COMMENT 'The category the listing belongs to',
  `sellerID` int(10) unsigned NOT NULL COMMENT 'The UID of the seller',
  `isActive` tinyint(1) NOT NULL COMMENT 'Whether or not the listing should appear on searches'
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `listingTagLink`
--

DROP TABLE IF EXISTS `listingTagLink`;
CREATE TABLE IF NOT EXISTS `listingTagLink` (
  `LID` int(10) unsigned NOT NULL COMMENT 'The Id of the listing the tag corresponds to',
  `TID` int(10) unsigned NOT NULL COMMENT 'The Id of the tag for the listing '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
`MID` int(10) unsigned NOT NULL COMMENT 'The message ID',
  `senderID` int(10) unsigned NOT NULL COMMENT 'The UID of the sender',
  `receiverID` int(10) unsigned NOT NULL COMMENT 'The UID of the reciever',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'The time the message was received',
  `subject` varchar(140) NOT NULL COMMENT 'The subject line of the message',
  `content` text NOT NULL COMMENT 'The message text'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
`OID` int(10) unsigned NOT NULL COMMENT 'The order''s ID',
  `LID` int(10) unsigned NOT NULL COMMENT 'The LID of the listing the order belongs to',
  `sellerID` int(10) unsigned NOT NULL COMMENT 'The UID of the seller',
  `buyerID` int(10) unsigned NOT NULL COMMENT 'The UID of the buyer',
  `contractID` int(10) unsigned NOT NULL COMMENT 'The contract ID'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
`TID` int(10) unsigned NOT NULL COMMENT 'The tag''s ID',
  `name` varchar(32) NOT NULL COMMENT 'The tag''s name',
  `categoryID` int(11) NOT NULL COMMENT 'The tag''s category'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`UID` int(10) unsigned NOT NULL COMMENT 'The User ID',
  `fname` varchar(64) NOT NULL COMMENT 'The user''s first name',
  `lname` varchar(64) NOT NULL COMMENT 'The user''s last name',
  `displayName` varchar(128) NOT NULL COMMENT 'The user''s desired display name',
  `email` varchar(128) NOT NULL COMMENT 'The user''s email, must be a unique entry',
  `phoneNumber` varchar(10) NOT NULL COMMENT 'The user''s phone number',
  `reputation` smallint(6) NOT NULL DEFAULT '0' COMMENT 'The reputation score of the user, user''s with low rep are unable to trade',
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'True if the user is an adminstrator',
  `acceptedToS` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'True if the user has accepted the ToS'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COMMENT='The users table';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`categoryID`), ADD UNIQUE KEY `categoryName` (`categoryName`);

--
-- Indexes for table `contracts`
--
ALTER TABLE `contracts`
 ADD PRIMARY KEY (`CID`);

--
-- Indexes for table `listings`
--
ALTER TABLE `listings`
 ADD PRIMARY KEY (`LID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
 ADD PRIMARY KEY (`MID`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
 ADD PRIMARY KEY (`OID`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
 ADD PRIMARY KEY (`TID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`UID`), ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `contracts`
--
ALTER TABLE `contracts`
MODIFY `CID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The ID of the contract';
--
-- AUTO_INCREMENT for table `listings`
--
ALTER TABLE `listings`
MODIFY `LID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The listing''s ID',AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
MODIFY `MID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The message ID',AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
MODIFY `OID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The order''s ID';
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
MODIFY `TID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The tag''s ID';
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `UID` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The User ID',AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
