<?php
/*****************************************************************************
 * File:    googleLogin.php
 * Created: 1 Dec 2016
 * Authors: Christian Badolato
 * Project: Retriever Marketplace
 * Description: php file with methods to allow login using google API tools.
 *			This file allows the webpage to use google login applications so
 * 			the users do not have to implement their own login mechanics. Also
 * 			contains a few mehtods to allow other functionalities.  
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

// Required includes
require_once("includes/google-api-php-client-2.0.3/vendor/autoload.php");
require_once("includes/util/databaseMethods.php");

// Setting the database and getting the connection
global $database;
if(!isset($database))
{
	$database = new Database();
}
if($database->isConnected())
{
	$conn = $database->getConnection();
}

// Set up Google Authorization
const CLIENT_ID = '909699052791-gh8u5dvrtm6fe3rnv52nepda2rssv3su.apps.googleusercontent.com';
const CLIENT_SECRET = 'r1ogF3AjVf8J08sZv5mmAxw5';
const REDIRECT_URI = 'http://item-retriever.ddns.net/welcome.php';

global $client;

$client = new Google_Client();
$client->setApplicationName("Item Retriever");
$client->setClientId(CLIENT_ID);
$client->setClientSecret(CLIENT_SECRET);
$client->setRedirectUri(REDIRECT_URI);
$client->setScopes('email profile');


$objOAuthService = new Google_Service_Oauth2($client);

global $authUrl;

// Handle logout request
if(isset($_REQUEST['logout']))
{
	unset($_SESSION['UID']);
	unset($_SESSION['access_token']);
	unset($_REQUEST['loutout']);
	$client->revokeToken();
	header('Location: welcome.php');
	exit();
}

// If the user just logged in
if(isset($_GET['code']))
{
	$client->authenticate($_GET['code']);
	$_SESSION['access_token'] = $client->getAccessToken();
	
	$userData = $objOAuthService->userinfo->get();
	
	// Not a UMBC email address
	$domain = $userData['hd'];
	if($domain != "umbc.edu")
	{
		unset($_SESSION['access_token']);
		$client->revokeToken();
		$error = "At this time, registration is limited to UMBC students. Please use your UMBC domain email address.";
		errorRedirect($error);
	}
	else 
	{
		// Get user information
		$userEmail = $userData['email'];
		$sql = "SELECT * FROM `users` WHERE `email`='$userEmail'";
		
		$stmt = $conn->prepare($sql);
		$stmt->execute();
		$userInfo = $stmt->fetch(PDO::FETCH_ASSOC);

		// If the user is new
		if(!$userInfo)
		{
			// Log them out and treat them as not logged in until they fill out required registration information
			$client->revokeToken();
			
			// Reassign the access token to disable 'sign out' and enable 'sign in' upon redirect
			$_SESSION['temp_access_token'] = $_SESSION['access_token'];
			unset($_SESSION['access_token']);
			
			// Save information that can be parsed from the login token
			$_SESSION['temp_fname'] = $userData['given_name'];
			$_SESSION['temp_lname'] = $userData['family_name'];
			$_SESSION['temp_email'] = $userData['email'];
			$_SESSION['temp_display_name'] = $userData['name'];
			
			// Redirect to the registration page
			header('Location: register.php');
			exit;
		}
		
		$_SESSION['UID'] = $userInfo['UID'];
		
		$redirect = REDIRECT_URI;
	}
}

// If the user is logged in
if(isset($_SESSION['access_token']) && $_SESSION['access_token'])
{
	unset($authUrl);
	$client->setAccessToken($_SESSION['access_token']);

// Otherwise generate the authorization url
} else {
  $authUrl = $client->createAuthUrl();
}

/*displayLogin
	No input 
	no output 
	description: Only prints the logo for login and logout,
	by checking if the user is logged in or not
*/
function displayLogin()
{
	global $authUrl;
	
	echo "<div class='login'>";
	if(isset($authUrl)) {
		echo "<a href='".$authUrl."'><img src='img/signin1.png' alt='Login' class='login'></a>";
	} else {
		echo "<a href='?logout'><img src='img/signout1.png' alt='Login' class='login'></a>";
	}
	echo "</div>";
}

/*revokeLogin
	no input 
	no output
	description: unsets the current UID, 
	and then uses revokeToken() to get the current UID.
	*/
function revokeLogin()
{
	global $client;
	unset($_SESSION['UID']);
	unset($_SESSION['access_token']);	
	$client->revokeToken();
}

/*getOAuthClient() 
	no input
	output: returns the client variable
	description: just returns the client variable 
	*/
function getOAuthClient()
{
	global $client;
	return $client;
}
