<?php
/*****************************************************************************
 * File:    register.php
 * Created: 1 Dec 2016
 * Authors: Christian Badolato
 * Project: Retriever Marketplace
 * Description: Enables new users to create an account.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

$thisDir = "home";
$thisSub = "";

require_once("includes/util/util.php");

//Verifying the user didn't just enter this address into the url bar
if(!isset($_SESSION['temp_fname']))
{
	$error = "No log-in data detected. Please use the \"Sign-In\" button at the top of this page.";
	errorRedirect($error);
}

// Fetching already given information
$fname = $_SESSION['temp_fname'];
$lname = $_SESSION['temp_lname'];
$email = $_SESSION['temp_email'];
$name = $_SESSION['temp_display_name'];

//If registration is completed, update information, and send the user to home

//If any value is posted, they all must have posted
if(isset($_POST['fname']))
{
	//Unset Session variables (can't be done before post or an error will be detected)
	unset($_SESSION['temp_fname']);
	unset($_SESSION['temp_lname']);
	unset($_SESSION['temp_email']);
	unset($_SESSION['temp_display_name']);
	
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$name = $_POST['displayname'];
	$email = $_POST['email'];
	$phone = $_POST['phone1'].$_POST['phone2'].$_POST['phone3'];

	//Terms of service must have been accepted if form was submitted
	$ToS = TRUE;
	
	//Add the user
	$query = $conn->prepare("INSERT INTO `users`(`fname`, `lname`, `displayName`, `email`, `phoneNumber`, `acceptedToS`) VALUES (?, ?, ?, ?, ?, ?)");
	$query->bindParam(1, $fname);
	$query->bindParam(2, $lname);
	$query->bindParam(3, $name);
	$query->bindParam(4, $email);
	$query->bindParam(5, $phone);
	$query->bindParam(6, $ToS);
	$query->execute();
	
	//Set UID
	$sql = "SELECT UID FROM `users` WHERE `email`='$email'";	
	$stmt = $conn->prepare($sql);
	$stmt->execute();
	$userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
	
	//Restore login and redirect to home
	$_SESSION['access_token'] = $_SESSION['temp_access_token'];
	$_SESSION['UID'] = $userInfo['UID'];
	header('Location: welcome.php');
	exit;
}

//Output Navigation Frame
require_once("includes/navFrame.php");

?>
<script src="includes/util/javascript.js"></script>

<div class='page'>
	<h2>Welcome to Retriever Marketplace!</h2>
	<h3>You're almost registered! Please provide the information below to complete your registration</h3>
	
	<div class="form">
	<form class='registrationForm' method='post' onSubmit='return validateRegistration();'>
		<fieldset><legend><strong>Account Info</strong></legend>
		First Name: <input type='text' name='fname' maxlength='64' title='Please enter your given name' value='<?php echo $fname?>' required='required'></input>
		<br/>
		Last Name: <input type='text' name='lname' maxlength='64' title='Please enter your family name' value='<?php echo $lname?>' required='required'></input>
		<br/>
		Display Name: <input type='text' name='displayname' maxlength='128' title='Please enter the name you wish others to see' value='<?php echo $name?>' required='required'></input>
		<br/>
		Email: <input type='text' name='emailview' maxlength='128' title='Your email address' value='<?php echo $email?>' readonly='readonly' required='required'></input>
		<input type='hidden' name='email' value='<?php echo $email?>'/>
		<br/>
		Phone Number: 
		<input type='text' name='phone1' required='required' size='3' maxlength='3' pattern='[0-9]{3}' onkeyup='boxJumpForPhone(this)' title='Please enter in the form: ###'></input> -
		<input type='text' name='phone2' required='required' size='3' maxlength='3' pattern='[0-9]{3}' onkeyup='boxJumpForPhone(this)' title='Please enter in the form: ###'></input> -
		<input type='text' name='phone3' required='required' size='4' maxlength='4' pattern='[0-9]{4}' title='Please enter in the form: ####'></input>
		<br/> *This will not be displayed on your profile* <br/>
		<br/>
		<input type='checkbox' name='tos' value='tos' required='required'>I agree to the Item Retriever Terms of Service<br/>
		<br/>
		<input type='submit' Value='Complete Registration'/>
		</fieldset>
	</form>
	</div>
</div>
<?php

//Output Footer
require_once("includes/footer.php");

?>
