<?php
/*****************************************************************************
 * File: 	listings.php
 * Created: 1 Dec 2016
 * Authors: Kush Patel, Thomas Wallace
 * Project: Retriever Marketplace
 * Description: Retrieves and displays posted listings.
 * 
 * Known Issues:
 * **************************************************************************/
session_start();

/*Pre-Load Section - NO HTML Output******************************************/
require_once("includes/util/util.php");

//Page Variable Declaration
$thisDir = "profile";
$thisSub = "listings";

//Verify User Login
if(!isLoggedIn())
{
	$error = "Registered Users Only. Please \"Sign-In\" to view this page.";
	errorRedirect($error);
}
else
{
	//Retrieve User Information
	$user = $database->getUserData($_SESSION['UID']);
}

//Verify User Connection
if($user == FALSE)
{
	$error = "Connection to database lost.";
	errorRedirect($error);
}

//Get User Listing to Delete from Database
if(isset($_GET['lid'])){
	
	//Delete Listings Data of User
	if($database->isConnected()) {
		$lid = $_GET['lid'];
		$stmt = $conn->prepare("DELETE FROM `listings` WHERE `LID` = $lid");
		$stmt->execute();
		
		//Redirect to User Listings to Verify Delete Successful
		header('Location: listings.php');
	}
	else 
	{
		$error = "Unable to Delete this Listing.";
		errorRedirect($error);
	}
}

//displayListings
function displayListings() {
	
	//External Globals Resolution
	global $database;
	global $conn;

	//Retrieve Listings Data of User
	if($database->isConnected()) {
		$sellerID = intval($_SESSION['UID']);
		$sql = "SELECT * FROM `listings` WHERE `sellerID`=$sellerID";	
		$stmt = $conn->prepare($sql);
		$stmt->execute();

		
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$listNum = $row['LID'];
			$title = $row['title'];
			$description = $row['description'];
			$image = $row['image'];
			
			echo '<h3>' . $title . '</h3>';
			echo '<a href="details.php?lid='.$listNum.'" onclick="post"><img height="180" width="180" src="data:image;base64,'.$image.' "></a>';
			echo '<br>';
			echo '<a href="listings.php?lid='.$listNum.'" onclick="post"><button>Delete Listing</button></a>';
			echo '<br>';
			echo '<br>';
		}
	}
	else {
		$error = "Connection to database lost.";
		errorRedirect($error);
		return;
	}

}

/*Output Section - HTML Output OK********************************************/

//Output Navigation Frame
require_once("includes/navFrame.php");

//Output Page Content
?>

<div class="page">
	<h2><?php echo $user['displayName'];?>'s Listings</h2>
	<hr>
	<p>View your listings information. Click on an image to see the details of that listing.</p>
	<div>
		<?php displayListings();?>
	</div>
</div>

<?php
//Output Footer
require_once("includes/footer.php");
?>
