CMSC 447 - Retriever Marketplace
============================
Authors: Christian Badolato
         Neh Patel
		 Kush Patel
		 Adam Wendler
		 Thomas Wallace
         

Site URL
--------

The URL for the project submission is:
http://item-retriever.ddns.net/


Raw File Descriptions
---------------------

The project submission contains the following files and directories:

  > README.txt     - Documentation for the submission.
  > src			   - Contains all source code for Retriever Marketplace
  > docs		   - Contains all design documents for Retriever Marketplace
  > database.sql   - The database dump for Retriever Marketplace


Server Setup
------------

The server is hosted through a Raspberry Pi using a LAMP server setup. The server's
DocumentRoot is a GitHub repository containing the files listed above. It is automatically
updated upon pusing to GitHub