import sys 

def main ():
    out1 = open("words.txt",'w') # contains the words
    out2 = open("wordsPronun.txt", 'w') # contains word pronunciation
    out3 = open("slangs.txt",'w') # contains slangs 
    out4 = open("slangsPronun.txt",'w') # contains slang pronunciation 
    out5 = open("abbrevWord.txt",'w') # contains shortened abbrev
    out6 = open("abbreviation.txt",'w') #constians full form 
    filename = sys.argv[-1]

    with open("dict.txt",'r') as f:
        for line in f:
            count = 0
            for x in line:
                if(x != "\t"):
                    count = count + 1
                else:
                    break
            out1.write(line.split(None,1)[0] + "\n")
            out2.write(line[count:])        

    with open(filename,'r') as f:
        for line in f:
            count = 0
            for x in line:
                if(x != "\t"):
                    count = count + 1
                else:
                    break
            out3.write(line.split(None,1)[0] + "\n")
            out4.write(line[count:])

    with open("abbrevDict.txt",'r') as f:
        for line in f:
            count = 0
            for x in line:
                if(x != "\t"):
                    count = count + 1
                else:
                    break
            out5.write(line[:count]+"\n")
            out6.write(line[count:])


    
    out1.close()
    out2.close()
    out3.close()
    out4.close()
    out5.close()
    out6.close()


main()
